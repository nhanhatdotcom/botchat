{
  object: 'page',
  entry: [{
    id: '',
    time: 1469004381054,
    messaging: [{
      sender: {
        id: '1143639809025650'
      },
      recipient: {
        id: ''
      },
      timestamp: 1469004604162,
      message: {
        is_echo: true,
        mid: 'mid.1469004604155:6821a858136cb6cf33',
        seq: 651,
        text: 'Nội dung tin nhắn mà khách hàng gửi',
        sticker_id: 657500007666590,
        attachments: [{
          type: 'image',
          payload: {
            url: 'https://scontent.xx.fbcdn.net/t39.1997-6/p100x100/10956886_789355404486707_112462968_n.png?_nc_ad=z-m'
          }
        }]
      },
      delivery: {
        mids: 'mid.1469005689002:983d4494c45cdab225',
        watermark: 1469005039470,
        seq: 661
      },
      read: {
        watermark: 1469005039470,
        seq: 662
      },
      postback: {
        payload: 'HELP'
      },
      optin: {
        ref: 'FB_MAIN_WEB_BTN'
      }
    }]
  }]
}
