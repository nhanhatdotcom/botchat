# hal-msg
 Facebook Messenger Bot Demo
## Usage
Config file `config/default.json`
### Install
```
$ npm install
$ npm build
$ npm start
```
"# botchat" 
